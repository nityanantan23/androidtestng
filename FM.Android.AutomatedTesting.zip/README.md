## AWS Device Farm Appium Cucumber Tests For Sample App

Sample Appium Cucumber tests for Android sample app that can be used on AWS Device Farm.

Instructions to package and run this test can be found [here.](https://aws.amazon.com/blogs/mobile/testing-mobile-apps-with-cucumber-and-appium-through-testng-on-aws-device-farm/)

## License

This library is licensed under the Apache 2.0 License. 
