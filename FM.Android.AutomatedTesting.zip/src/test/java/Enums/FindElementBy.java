package Enums;

public enum FindElementBy {
	XPath,
	Id
}