package Tests;


import Common.AppInteraction;
import Pages.m5;
import Pages.m6;
import Tests.AbstractBaseTests.TestBase;
import cucumber.api.CucumberOptions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

@CucumberOptions(
        strict = true,
        monochrome = true,
        features = "classpath:Step5_M6Test",
        plugin = {"pretty"}
)

public class Step5_M6Test extends TestBase {
    private m6 M6;

    @BeforeTest
    @Override
    public void setUpPage() {
        M6 = new m6(driver);
    }

    @Given("^I initiate M6 Page$")
    public void initPage() {
        if (M6 == null) {
            M6 = new m6(driver);
        }
        if (appInteraction == null) {
            this.appInteraction = new AppInteraction(driver);
        }
        this.appInteraction.WriteToReport("Background: I initiate feebacl Page : " + "Passed");

        Assert.assertTrue(true);
    }



//    @Then("^I am able to add list$")
//    public void click_banner() throws InterruptedException, Exception {
//        boolean isTestSuccess = true;
//
//        if (appInteraction == null) {
//            this.appInteraction = new AppInteraction(driver);
//        }
//
//        try {
//            isTestSuccess = M6.isAbleToClick();
//        } catch (Exception e) {
//            e.printStackTrace();
//            isTestSuccess = false;
//        } this.appInteraction.WriteToReport("Scenario: I am able to click the delete_address_menu button : " + (isTestSuccess ? "Passed" : "Failed"));
//
//        Assert.assertTrue(isTestSuccess);
//    }
////
//    @Then("^I am able to select_location pickup$")
//    public void select_locations_pickup() throws InterruptedException, Exception {
//        boolean isTestSuccess = true;
//
//        if (appInteraction == null) {
//            this.appInteraction = new AppInteraction(driver);
//        }
//
//        try {
//            isTestSuccess = M6.select_location_pickup();
//        } catch (Exception e) {
//            e.printStackTrace();
//            isTestSuccess = false;
//        } this.appInteraction.WriteToReport("Scenario: I am able to click the delete_address_menu button : " + (isTestSuccess ? "Passed" : "Failed"));
//
//        Assert.assertTrue(isTestSuccess);
//    }
}
