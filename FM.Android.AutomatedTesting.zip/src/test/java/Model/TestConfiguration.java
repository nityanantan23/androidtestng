package Model;

public class TestConfiguration {
	public String TestResultSender;
	public String TestResultRecipient;
	public String DriverID;
	public String Password;
	public String Otp;
}
