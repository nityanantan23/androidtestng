package Pages;

import Enums.FindElementBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class m6 extends BasePage {
    public m6(AndroidDriver<MobileElement> driver) {
        super(driver);

    }

    public boolean isAbleToClick() throws InterruptedException{
        String CategoryButton = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.drawerlayout.widget.DrawerLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView[2]/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ImageView[1]";
        MobileElement appLoadBannerElement = null;
        Thread.sleep(5000);
        try {
            appLoadBannerElement = this.appInteraction.FindElement(CategoryButton, FindElementBy.XPath, NO_DELAY);
            this.appInteraction.ClickElement(CategoryButton, FindElementBy.XPath, NO_DELAY);
            Thread.sleep(5000);
        }
        catch(Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

}